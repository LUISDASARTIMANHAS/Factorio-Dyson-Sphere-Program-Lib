-- presets Basicos do mods
require("graficos/style.lua")
require("data.recursos")
require("data.matrix")
require("data.technology")
-- require("data/soundMaker")
require("data/grupos")

-- blocos e qeuipamentos
-- require("data/blocos/Dyson-Sphere-Program-Lib-equipment")