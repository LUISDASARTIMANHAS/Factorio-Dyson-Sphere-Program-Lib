-- presets Basicos do mods
require("graficos/style.lua")
-- require("data/recursos")
-- require("data/technology")
-- require("data/soundMaker")
-- require("data/grupos")

-- blocos e qeuipamentos
-- require("data/blocos/quantum-teleporter-equipment")